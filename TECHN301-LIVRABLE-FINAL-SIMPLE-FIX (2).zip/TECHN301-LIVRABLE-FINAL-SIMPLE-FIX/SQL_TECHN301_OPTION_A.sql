-- TECHN301 (Option A) — Tables + Storage public
-- 1) Crée les tables (si pas déjà fait) puis 2) crée le bucket Storage "techn301" + policies.

create extension if not exists pgcrypto;

-- ===== Tables principales =====
create table if not exists public.students (
  id bigserial primary key,
  first_name text not null,
  last_name  text not null,
  email      text not null unique,
  created_at timestamptz not null default now()
);

create table if not exists public.accounts (
  email text primary key,
  code  text not null check (code ~ '^[0-9]{4}$'),
  role  text not null check (role in ('admin','prof','student')),
  student_id bigint null references public.students(id) on delete set null,
  provisional boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.classes (
  id bigserial primary key,
  name text not null unique,
  created_at timestamptz not null default now()
);

create table if not exists public.student_classes (
  student_id bigint primary key references public.students(id) on delete cascade,
  class_id bigint not null references public.classes(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.teacher_classes (
  id bigserial primary key,
  teacher_email text not null references public.accounts(email) on delete cascade,
  class_id bigint not null references public.classes(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (teacher_email, class_id)
);

-- Matières
create table if not exists public.subjects (
  id bigserial primary key,
  name text not null unique,
  created_at timestamptz not null default now()
);

create table if not exists public.class_subjects (
  class_id bigint not null references public.classes(id) on delete cascade,
  subject_id bigint not null references public.subjects(id) on delete cascade,
  primary key (class_id, subject_id)
);

create table if not exists public.teacher_subjects (
  teacher_email text not null references public.accounts(email) on delete cascade,
  subject_id bigint not null references public.subjects(id) on delete cascade,
  primary key (teacher_email, subject_id)
);

-- Notes
create table if not exists public.grades (
  id bigserial primary key,
  student_id bigint not null references public.students(id) on delete cascade,
  kind text not null check (kind in ('eval','devoir')),
  title text not null,
  score numeric not null,
  out_of numeric not null default 20,
  author text not null,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

-- Discipline / NPunitions
create table if not exists public.discipline_events (
  id bigserial primary key,
  student_id bigint not null references public.students(id) on delete cascade,
  type text not null,
  reason text null,
  detail text null,
  minutes integer null check (minutes is null or minutes > 0),
  points_delta numeric not null default 0,
  author text not null,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

-- Devoirs
create table if not exists public.assignments (
  id bigserial primary key,
  class_id bigint not null references public.classes(id) on delete cascade,
  title text not null,
  detail text null,
  due_at timestamptz null,
  author text not null references public.accounts(email) on delete restrict,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.submissions (
  id bigserial primary key,
  assignment_id bigint not null references public.assignments(id) on delete cascade,
  student_id bigint not null references public.students(id) on delete cascade,
  text text null,
  created_at timestamptz not null default now()
);

-- Fichiers (metadata) + URL publique
create table if not exists public.files_meta (
  id uuid primary key default gen_random_uuid(),
  owner_email text not null references public.accounts(email) on delete cascade,
  name text not null,
  mime text not null default 'application/octet-stream',
  size_bytes bigint not null default 0,
  storage_path text not null,
  public_url text null,
  created_at timestamptz not null default now()
);

-- Lien rendu ↔ fichiers
create table if not exists public.submission_files (
  submission_id bigint not null references public.submissions(id) on delete cascade,
  file_id uuid not null references public.files_meta(id) on delete cascade,
  primary key (submission_id, file_id)
);

-- Messagerie
create table if not exists public.messages (
  id bigserial primary key,
  from_email text not null references public.accounts(email) on delete cascade,
  from_role  text not null check (from_role in ('admin','prof','student')),
  from_student_id bigint null references public.students(id) on delete set null,
  to_type text not null check (to_type in ('class','direct')),
  to_class_id bigint null references public.classes(id) on delete cascade,
  to_email text null references public.accounts(email) on delete cascade,
  text text null,
  created_at timestamptz not null default now(),
  check (
    (to_type = 'class'  and to_class_id is not null and to_email is null)
    or
    (to_type = 'direct' and to_email is not null and to_class_id is null)
  )
);

create table if not exists public.message_files (
  message_id bigint not null references public.messages(id) on delete cascade,
  file_id uuid not null references public.files_meta(id) on delete cascade,
  primary key (message_id, file_id)
);

-- ===== Storage Option A (bucket public) =====
insert into storage.buckets (id, name, public)
values ('techn301', 'techn301', true)
on conflict (id) do nothing;

drop policy if exists "techn301_public_read" on storage.objects;
create policy "techn301_public_read"
on storage.objects for select to public
using (bucket_id = 'techn301');

drop policy if exists "techn301_public_insert" on storage.objects;
create policy "techn301_public_insert"
on storage.objects for insert to public
with check (bucket_id = 'techn301');

drop policy if exists "techn301_public_update" on storage.objects;
create policy "techn301_public_update"
on storage.objects for update to public
using (bucket_id = 'techn301')
with check (bucket_id = 'techn301');

drop policy if exists "techn301_public_delete" on storage.objects;
create policy "techn301_public_delete"
on storage.objects for delete to public
using (bucket_id = 'techn301');
